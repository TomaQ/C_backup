#include<stdio.h>

int main()
{
	printf("iajsds\n");
	return 0;
}
