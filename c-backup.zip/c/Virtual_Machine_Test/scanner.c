//Thomas Tavarez
//Homework #2

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

#define MAX_IDENTIFIER_LENGTH 11
#define MAX_NUMBER_LENGTH 5

typedef struct node
{
    char *word;
    struct node *next;

} node;

typedef enum {
    nulsym = 1, identsym, numbersym, plussym, minussym,
    multsym,  slashsym, oddsym, eqsym, neqsym, lessym, leqsym,
    gtrsym, geqsym, lparentsym, rparentsym, commasym, semicolonsym,
    periodsym, becomessym, beginsym, endsym, ifsym, thensym,
    whilesym, dosym, callsym, constsym, varsym, procsym, writesym,
    readsym , elsesym
} token_type;

node *BeginsWithLetter(char firstLetter, FILE *input, node* tail, FILE *output);
node *BeginsWithNumber(char firstDigit, FILE *input, node* tail, FILE *output);
node *BeginsWithSymbol(char firstSymbol, FILE *input, node* tail, FILE *output);
void findLexeme(FILE *out, char *text, FILE *list);
node *createNode();

int main(void)
{
    int c;
    char letter;

    int i = 0;

    node *head, *tail;
    head = tail = createNode();


    FILE *input = fopen("input.txt", "rb");

    if (input == NULL) {
        printf("\"input.txt\" file not found\n");
        exit(1);
    }

    FILE *output = fopen("cleaninput.txt", "w+");

    c = fgetc(input);

	while(c != EOF) {

        if(isalpha(c))
        {
            letter = c;
            tail = BeginsWithLetter(c, input, tail, output);
            c = fgetc(input);
        }

        else if(isdigit(c))
        {
            tail = BeginsWithNumber(c, input, tail, output);
            c = fgetc(input);
        }

        else if(ispunct(c))
        {
            letter = c;
            tail = BeginsWithSymbol(c, input, tail, output);
            c = fgetc(input);
        }

        else
        {
            fprintf(output, "%c", c );
            c = fgetc(input);
        }
    }

    fclose (input);

    output = fopen("lexemetable.txt", "w");
    FILE *outList = fopen("lexemelist.txt", "w+");

    fprintf(output, "lexeme\t\ttoken type\n");

    for (; head->next != NULL; head = head->next)
    {
        fprintf(output, "%s\t\t", head->word);
        findLexeme(output, head->word, outList);
    }

    fclose(outList);
    fclose(output);
}

node *BeginsWithLetter(char firstLetter, FILE *input, node *tail, FILE *output)
{
    int wordLen = 11;
    int nextLetter;
    int letterPos = 1;

    char *word = calloc(wordLen + 1, sizeof(char));

    strcpy(word, "");
    word[0] = firstLetter;

    nextLetter = fgetc(input);

    while(isalpha(nextLetter) || isdigit(nextLetter))
    {
        if (letterPos >= wordLen)
        {
            wordLen *= 2;
            word = realloc(word, wordLen + 1);
        }
        word[letterPos] = nextLetter;
        letterPos++;
        nextLetter = fgetc(input);
    }

    tail->word = malloc(strlen(word) + 1);
    strcpy(tail->word, word);
    tail->next = createNode();

    free(word);

    if (nextLetter != EOF)
        fseek(input, -1, SEEK_CUR);

    fprintf(output, "%s", tail->word);

    return tail->next;
}

node *BeginsWithNumber(char firstDigit, FILE *input, node *tail, FILE *output)
{
    int numDigits = 5;
    int digitPos = 1;
    int nextDigit;

    char *word = calloc(numDigits + 1, sizeof(char));
    strcpy(word, "");
    word[0] = firstDigit;

    nextDigit = fgetc(input);

    while(isdigit(nextDigit))
    {
        if(digitPos >= numDigits)
        {
            numDigits *= 2;
            word = realloc(word, numDigits + 1);
        }
        word[digitPos] = nextDigit;
        digitPos++;
        nextDigit = fgetc(input);
    }

    if(isalpha(nextDigit))
    {
        printf("Error. Variable does not start with a letter. \n");
        exit(1);
    }

    tail->word = malloc(strlen(word) + 1);
    strcpy(tail->word, word);
    tail->next = createNode();

    if(nextDigit != EOF)
        fseek(input, -1, SEEK_CUR);

    free(word);
    fprintf(output, "%s", tail->word);

    return tail->next;
}

node *BeginsWithSymbol(char firstSymbol, FILE *input, node* tail, FILE *output)
{
    int maxNumSymbols = 2;

    char *symbol = calloc(maxNumSymbols + 1, sizeof(char));

    strcpy(symbol, "");
    symbol[0] = firstSymbol;

    switch(firstSymbol)
    {
        case '/':
        {
            char nextChar;
            nextChar = fgetc(input);
            if(nextChar == '*')
            {
                nextChar = fgetc(input);
                do
                {
                    while (nextChar != '*')
                    {
                        if(nextChar == EOF)
                         {
                             printf("Error. No end to comments.\n");
                             exit(1);
                         }
                        nextChar = fgetc(input);
                    }
                    nextChar = fgetc(input);
                } while(nextChar != '/');

                return tail;
            }
            else
            {
                if(nextChar != EOF)
                    fseek(input, -1, SEEK_CUR);
            }
            break;
        }

        case '<':
        {
            char nextChar;

            int digitPos = 1;

            nextChar = fgetc(input);

            if(nextChar == '=' || nextChar == '>')
            {
                symbol[digitPos] = nextChar;
            }
            else
            {
                if(nextChar != EOF)
                    fseek(input, -1, SEEK_CUR);

            }
            break;
        }

        case '>':
        {
            char nextChar;

            int digitPos = 1;

            nextChar = fgetc(input);

            if(nextChar == '=')
            {
                symbol[digitPos] = nextChar;
            }
            else
            {
                if(nextChar != EOF)
                    fseek(input, -1, SEEK_CUR);

            }
            break;
        }

        case ':':
        {
            char nextChar;

            int digitPos = 1;

            nextChar = fgetc(input);

            if(nextChar == '=')
            {
                symbol[digitPos] = nextChar;
            }
            else
            {
                printf("Error. Invalid symbol.\n");
                exit(1);
            }
            break;
        }

        case '+' :
        case '-' :
        case '*' :
        case '(' :
        case ')' :
        case '=' :
        case ',' :
        case '.' :
        case ';' :
            break;
        default :
            printf("Error. Invalid symbol.\n");
            exit(1);

    }

    tail->word = malloc(strlen(symbol) + 1);
    strcpy(tail->word, symbol);
    tail->next = createNode();

    free(symbol);
    fprintf(output, "%s", tail->word);

    return tail->next;
}

node *createNode()
{
    node *ptr = malloc(sizeof(node));
    ptr->next = NULL;
    return ptr;
}

void findLexeme(FILE *output, char *text, FILE *outList)
{
    int index;

    if(isalpha(text[0]))
    {
        if (strlen(text) > MAX_IDENTIFIER_LENGTH)
        {
            printf("Error. Variable name is too long. \n" );
            exit(1);
        }
        if(strcmp(text, "odd") == 0){
            fprintf(output, "%d\n", 8);
            fprintf(outList, "%d ", 8);
        }
        else if(strcmp(text, "begin") == 0){
            fprintf(output, "%d\n", 21);
            fprintf(outList, "%d ", 21);
        }
        else if(strcmp(text, "end") == 0) {
            fprintf(output, "%d\n", 22);
            fprintf(outList, "%d ", 22);
        }
        else if(strcmp(text, "if") == 0){
            fprintf(output, "%d\n", 23);
            fprintf(outList, "%d ", 23);
        }
        else if ( strcmp(text, "then") == 0){
            fprintf(output, "%d\n", 24);
            fprintf(outList, "%d ", 24);
        }
        else if(strcmp(text, "while") == 0){
            fprintf(output, "%d\n", 25 );
            fprintf(outList, "%d ", 25 );
        }
        else if(strcmp(text, "do") == 0){
            fprintf(output, "%d\n", 26 );
            fprintf(outList, "%d ", 26 );
        }
        else if( strcmp(text, "call") == 0){
            fprintf(output, "%d\n", 27 );
            fprintf(outList, "%d ", 27 );
        }
        else if(strcmp(text, "const") == 0) {
            fprintf(output, "%d\n", 28 );
            fprintf(outList, "%d ", 28 );
        }
        else if (strcmp(text, "var") == 0){
            fprintf(output, "%d\n", 29 );
            fprintf(outList, "%d ", 29 );
        }
        else if (strcmp(text, "procedure") == 0) {
            fprintf(output, "%d\n", 30 );
            fprintf(outList, "%d ", 30 );
        }
        else if (strcmp(text, "write") == 0) {
            fprintf(output, "%d\n", 31 );
            fprintf(outList, "%d ", 31 );
        }
        else if (strcmp( text, "read") == 0) {
            fprintf(output, "%d\n", 32 );
            fprintf(outList, "%d ", 32 );
        }
        else if (strcmp( text, "else") == 0) {
            fprintf(output, "%d\n", 33);
            fprintf(outList, "%d ", 33);
        }

        else
        {
            fprintf(output, "2\n" );
            fprintf (outList, "2 %s ", text);
        }
    }

    else if(isdigit(text[0]))
    {
        if(strlen(text) > MAX_NUMBER_LENGTH )
        {
            printf("Error. Number is too large. \n" );
            exit(1);
        }
        fprintf(output, "3\n");
        fprintf(outList, "3 %s ", text);
    }

    else if(ispunct(text[0]))
    {
        switch (text[0])
        {
            case '+':
                fprintf(output, "%d\n", 4);
                fprintf(outList, "%d ", 4);
                break;
            case '-':
                fprintf(output, "%d\n", 5);
                fprintf(outList, "%d ", 5);
                break;
            case '*':
                fprintf(output, "%d\n", 6);
                fprintf(outList, "%d ", 6);
                break;
            case '/':
                fprintf(output, "%d\n", 7);
                fprintf(outList, "%d ", 7);
                break;
            case '(':
                fprintf(output, "%d\n", 15);
                fprintf(outList, "%d ", 15);
                break;
            case ')':
                fprintf(output, "%d\n", 16);
                fprintf(outList, "%d ", 16);
                break;
            case '=':
                fprintf(output, "%d\n", 9);
                fprintf(outList, "%d ", 9);
                break;
            case ',':
                fprintf(output, "%d\n", 17);
                fprintf(outList, "%d ", 17);
                break;
            case '.':
                fprintf(output, "%d\n", 19);
                fprintf(outList, "%d ", 19);
                break;
            case '<':
                if(strlen(text) > 1)
                {
                    if(strcmp(text, "<>") == 0)
                    {
                        fprintf(output, "%d\n", 10);
                        fprintf(outList, "%d ", 10);
                    }
                    else if(strcmp(text, "<=") == 0)
                    {
                        fprintf(output, "%d\n", 12);
                        fprintf(outList, "%d ", 12);
                    }
                }
                else
                {
                    fprintf(output, "%d\n", 11);
                    fprintf(outList, "%d ", 11);
                }
                break;
            case '>':
                if(strlen(text) > 1)
                {
                    if(strcmp(text, ">=") == 0)
                    {
                        fprintf(output, "%d\n", 14);
                        fprintf(outList, "%d ", 14);
                    }
                }
                else
                {
                    fprintf(output, "%d\n", 13);
                    fprintf(outList, "%d ", 13);
                }
                break;
            case ';':
                fprintf(output, "%d\n", 18);
                fprintf(outList, "%d ", 18);
                break;
            case ':':
                fprintf(output, "%d\n", 20);
                fprintf(outList, "%d ", 20);
                break;
        }
    }
}
