/**************************************
University of Central Florida
COP3404 System Software
**************************************/

HW3 (Parser/Code Generator)
Test Case 1

This is a simple test case, with a very
basic PL/0 program. 

It only serves to verify that the correct 
amount of space is reserved for main's 
activation record, and that the correct 
address are assigned to variables.
