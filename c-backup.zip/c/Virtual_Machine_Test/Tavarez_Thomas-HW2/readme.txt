To compile:

gcc scanner.c -o a.out

To run:

./a.out