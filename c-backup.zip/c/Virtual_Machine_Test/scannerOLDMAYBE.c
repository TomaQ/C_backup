//Thomas Tavarez
//September 19, 2014
//Homework #2

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#define MAX_CHAR_LENGTH 11
#define MAX_NUM_LENGTH 5
#define NUM_RESERVED_WORDS 14
#define NUM_SYMBOLS 13
#define NUM_ALLOWED_SYMBOLS 15

typedef enum {
    nulsym = 1, identsym, numbersym, plussym, minussym, multsym, slashsym,
    oddsym, eqsym, neqsym, lessym, leqsym, gtrsym, geqsym, lparentsym, rparentsym,
    commasym, semicolonsym, periodsym, becomessym, beginsym, endsym, ifsym, thensym,
    whilesym, dosym, callsym, constsym, varsym, procsym, writesym, readsym , elsesym
}token_type;

char *reservedWords[] = { "const", "var", "procedure", "call", "begin", "end", "if", "then", "else", "while", "do", "read", "write", "odd" };

char symbols[] = {'+', '-', '*', '/', '(', ')', '=', ',' , '.', '<', '>',  ';' , ':' };
char *allowedSymbols[] = {"+", "-", "*", "/", "(", ")", "<=", ">=" "=", "<", ">", ",", ";", ":=", "."};

int outputIndex = 0;
int currentpos = 0;
int length = 0;
char program[10000];
char *output[10000]; //the output that get's printed to lexemelist and table

FILE *input;
FILE *clean;
FILE *outList;
FILE *outTable;


int comments(int i);
void printClean();
//void getTokens();
void printTable();
void printList();
//int isReserved(char c[], int i);

int main() {
    int j;
    for(j = 0; j < 10000; j++){
        output[j] = malloc(sizeof(char) * MAX_CHAR_LENGTH);
    }

    input = fopen("input.txt", "r");
    clean = fopen("cleaninput.txt", "w");
    outList = fopen("lexemelist.txt", "w");
    outTable = fopen("lexemetable.txt", "w");

    while(!feof(input)){
        program[length] = fgetc(input);
        length = length + 1;
    }

    printClean();
    fclose(input);
    fclose(clean);

    clean = fopen("cleaninput.txt", "r");

    length = 0;
    while(!feof(clean)){
        program[length] = fgetc(clean);
        length = length + 1;
    }

    //getTokens();
    while(currentpos < length-1){

		int save = currentpos;
		// Ident or Reserved Word - must start with alpha character
		if(isalpha(program[currentpos])){
			int success = alpha(program, save);
			if(!success){
				printf("ERROR");
			}
		}

		else if(isdigit(program[currentpos])){
			int success = number(program, save);
			if(!success){
				printf("ERROR");
			}
		}
		// other cases here
		else if(isSymbol(program[currentpos])){
            int success = 1;
		}
		else
			currentpos++;

	}

    printTable();
    printList();

    fclose(clean);
    fclose(outList);
    fclose(outTable);

    return 0;
}
///////////////////
int alpha(char* program, int save){
	// Character after the initial alpha character
	currentpos++;
	// Keep looking forward until a character is not alphanumeric
	while(isalnum(program[currentpos])){
		currentpos++;
	}
	// Get the length of the string by subtracting the first character
	// position from the last character position in the program array
	int strlength = currentpos - save;
	// String is too long - this is an error!
	if(strlength > MAX_CHAR_LENGTH)
		return 0;
	// Copy the string from the program array into a new char array
	// so that it can be compared to the reserved words
	char str[strlength+1];
	strncpy(str, &program[save], strlength);
	str[strlength] = '\0';
	int reserved = isReserved(str);
	if(reserved != -1){
		printf("%s is reserved\n", str);

		emit(reserved, output[outputIndex], 7);
		outputIndex += 1;

	}
	else{
		printf("%s is an ident\n", str);

        char temp[13];
		emit(reserved, temp, 7);
		strcpy(output[outputIndex], temp);
		strcpy(output[outputIndex+1], str);
		outputIndex += 2;
	}
	return 1;
}

int isReserved(char* str){
	int i;
	for(i = 0; i < NUM_RESERVED_WORDS; i++){
		if(strcmp(str, reservedWords[i]) == 0){
			return i;
		}
	}
	return -1;
}


int number(char* program, int save){
	// Convert the starting digit from a char to an int
	int num = program[save]-'0';
	// Advance to the next character after the saved character
	currentpos++;
	// Keep advancing until a non-digit character is found
	while(isdigit(program[currentpos])){
		// Adjust the number so that the new number is in the ones place
		num = num*10 + (program[currentpos]-'0');
		currentpos++;
	}
	// Error - Probably an ident that starts with a number!
	if(isalpha(program[currentpos]))
		return 0;
	// Error - Number is too big!
	if((currentpos - save) > MAX_NUM_LENGTH)
		return 0;
	printf("%d", num);

	emit(num, output[outputIndex], 7);//maybe
	outputIndex += 1;
	return 1;
}
/////////////////////////
/*void getTokens(){

//read 1 by one into char[], make function to check for reserved and symbolsymbols, return enum of that, need currentpos and char[] index
    char temp[MAX_CHAR_LENGTH];
    memset(temp, 0, sizeof(temp));

    int currentpos, i = -1;
    for(currentpos = 0; currentpos < length; currentpos++){
        i++;

        if(isalpha(program[currentpos])){
            temp[i] = program[currentpos];

            if(isReserved(temp, currentpos) || i > MAX_CHAR_LENGTH){
                i = -1;
                strcpy(temp, "");
            }

            /*if(isVar(temp, currentpos)){

            }
        }

        if(isSymbol(temp, currentpos)){
            i = -1;
            strcpy(temp, "");
        }


    }
}*/

/*int isReserved(char word[], int currentpos){
    int i;
    for(i = 0; i < NUM_RESERVED_WORDS; i++){
        printf("%d %s %s\n", currentpos, reservedWords[i], word);
        if(strcmp(reservedWords[i], word) == 0 && (!isalpha(prograprintf("asd");m[currentpos+1]) || !isdigit(program[currentpos+1]))){
            strcpy(output[current], reservedWords[i]);
            current += 1;
            return 1;
        }
    }
    return 0;
}*/

int isSymbol(char word[], int currentpos){
    int i;
    for(i = 0; i < NUM_ALLOWED_SYMBOLS; i++){
        if(strcmp(word, allowedSymbols[i]) == 0){ //for now
        //if(< or > or )
            strcpy(output[outputIndex], allowedSymbols[i]);
            outputIndex += 1;
            return 1;
        }
    }
    return 0;
}

int isVar(char word[], int currentpos){
     return 0;
}

int comments(int i) {

     if(program[i] == '/' && program[i+1] == '*'){
        i += 2;

        while(program[i] != '*' && program[i+1] != '/'){
            i++;
        }
        i += 2; //since the position is at *, you need to increment it past the /
     }
     return i;
}

void printClean(){ //prints the program without comments
    int i;
    for(i = 0; i < length - 1; i++){
        i = comments(i);
        fprintf(clean, "%c", program[i]);
    }
}

void printTable(){
    fprintf(outTable, "lexeme\ttoken type");
    int i;
    for(i = 0; i < length; i++){

    }
}

void printList(){
    int i;
    for(i = 0; i < outputIndex; i++){
        if(strcmp(output[i], " ") != 0 && strcmp(output[i], "  ") != 0){
            fprintf(outList, "%s ", output[i]);
        }
    }

}

